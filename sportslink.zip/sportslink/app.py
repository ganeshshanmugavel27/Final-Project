from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "sportslink_secret_key"

# ---------------- DATABASE CONNECTION ----------------
def get_db():
    return sqlite3.connect("sportslink.db")


# ---------------- HOME / LOGIN ----------------
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        db = get_db()
        c = db.cursor()
        user = c.execute(
            "SELECT * FROM users WHERE email=? AND password=?",
            (email, password)
        ).fetchone()
        db.close()

        if user:
            session["user_id"] = user[0]
            session["role"] = user[4]

            if user[4] == "player":
                return redirect("/player")
            else:
                return redirect("/team")

    return render_template("login.html")


# ---------------- REGISTER ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        role = request.form["role"]

        db = get_db()
        c = db.cursor()
        c.execute(
            "INSERT INTO users VALUES (NULL,?,?,?,?)",
            (name, email, password, role)
        )
        db.commit()
        db.close()

        return redirect("/login")

    return render_template("register.html")


# ---------------- PLAYER DASHBOARD ----------------
@app.route("/player", methods=["GET", "POST"])
def player():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        role = request.form["role"]
        skill = request.form["skill"]
        location = request.form["location"]

        db = get_db()
        c = db.cursor()
        c.execute(
            "INSERT INTO player_profiles VALUES (?,?,?,?)",
            (session["user_id"], role, skill, location)
        )
        db.commit()
        db.close()

    return render_template("player.html")


# ---------------- TEAM DASHBOARD ----------------
@app.route("/team", methods=["GET", "POST"])
def team():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        role_needed = request.form["role"]
        date = request.form["date"]
        location = request.form["location"]

        db = get_db()
        c = db.cursor()
        c.execute(
            "INSERT INTO requirements VALUES (NULL,?,?,?,?)",
            (session["user_id"], role_needed, date, location)
        )
        db.commit()
        db.close()

    return render_template("team.html")


# ---------------- MATCHING (RULE-BASED) ----------------
@app.route("/matches")
def matches():
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()
    c = db.cursor()

    matches = c.execute("""
        SELECT requirements.id, requirements.role_needed, requirements.date, requirements.location
        FROM requirements
        JOIN player_profiles
        ON requirements.role_needed = player_profiles.role
        WHERE player_profiles.user_id = ?
    """, (session["user_id"],)).fetchall()

    db.close()

    return render_template("matches.html", matches=matches)


# ---------------- I'M IN FEATURE ----------------
@app.route("/im_in/<int:req_id>")
def im_in(req_id):
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()
    c = db.cursor()
    c.execute(
        "INSERT INTO interests VALUES (?,?)",
        (session["user_id"], req_id)
    )
    db.commit()
    db.close()

    return redirect("/matches")


# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)
