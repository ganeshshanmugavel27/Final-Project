import sqlite3

conn = sqlite3.connect("sportslink.db")
c = conn.cursor()

c.execute("""
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    password TEXT,
    role TEXT
)
""")

c.execute("""
CREATE TABLE player_profiles (
    user_id INTEGER,
    role TEXT,
    skill TEXT,
    location TEXT
)
""")

c.execute("""
CREATE TABLE requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER,
    role_needed TEXT,
    date TEXT,
    location TEXT
)
""")

conn.commit()
conn.close()
print("Database created successfully")
